/* =========================================================
   提瓦特一言（kokuu-quote）· 前端组件 v2
   由插件注入。依赖 kokuu-home / kokuu-ui 主题以统一视觉。

   v2 变更：去掉分类筛选，只保留「显示 + 换一句」。
   形态：首页 = 融入主题的引言横幅；后台 = 侧边栏底部紧凑短句。
   ========================================================= */
(function () {
  "use strict";

  function getBase() {
    var b = window.blessing || {};
    return (b.base_url || "").replace(/\/+$/, "");
  }

  // 元素 → 颜色（点缀用，呼应七元素）
  function elColor(el) {
    switch (el) {
      case "风": return "#7FB2E5";
      case "岩": return "#C8A96A";
      case "雷": return "#A98BE0";
      case "水": return "#5FC6D9";
      case "火": return "#E8794A";
      case "草": return "#7FB069";
      case "冰": return "#8FD4E0";
      default:   return "#8B7FD4";
    }
  }

  function fetchQuote() {
    return fetch(getBase() + "/plugin/kokuu-quote/random", {
      credentials: "same-origin",
      headers: { Accept: "application/json", "X-Requested-With": "XMLHttpRequest" }
    })
      .then(function (r) { return r.json(); })
      .catch(function () {
        return { text: "风带来了故事的种子，时间使之发芽。", by: "时之风", el: "风" };
      });
  }

  // 顶栏空间有限：台词与出处各自限长，避免撑破胶囊
  var MAX_TEXT = 22;   // 台词最多显示字数
  var MAX_BY = 8;      // 出处最多显示字数

  function clip(s, n) {
    s = String(s == null ? "" : s);
    return s.length > n ? s.slice(0, n) + "…" : s;
  }

  function fill(root, q) {
    var t = root.querySelector(".kq-text");
    var by = root.querySelector(".kq-by");
    if (t) { t.textContent = clip(q.text, MAX_TEXT); t.title = q.text || ""; }
    if (by) { by.textContent = clip(q.by, MAX_BY); }
    root.style.setProperty("--kq-el", elColor(q.el));
  }

  function load(root) {
    root.classList.remove("kq-swap");
    void root.offsetWidth;                      // 触发重排以重放动画
    root.classList.add("kq-swap");
    fetchQuote().then(function (q) { fill(root, q); });
  }

  /* ---------------- 首页：不注入（保持首页纯净） ---------------- */
  /* 用户要求首页不显示一言，故此处不挂载 */

  /* ---------------- 后台：顶栏右侧一言 ---------------- */
  function mountTopbar() {
    if (document.querySelector(".kq-top")) { return; }

    // 顶栏右侧列表：优先 AdminLTE 侧栏版的 .navbar-nav.ml-auto，
    // 兼容顶栏布局（skinlib）里没有 ml-auto 的情况
    var bar =
      document.querySelector(".main-header .navbar-nav.ml-auto") ||
      document.querySelector(".main-header .navbar-custom-menu") ||
      document.querySelector(".main-header .navbar-nav:last-of-type");
    if (!bar) { return; }

    var li = document.createElement("li");
    li.className = "nav-item kq-item";
    li.innerHTML =
      '<a class="nav-link kq-top" href="#" role="button" title="点击换一句">' +
        '<span class="kq-body">' +
          '<span class="kq-text">…</span>' +
          '<span class="kq-by"></span>' +
        '</span>' +
        '<span class="kq-refresh" aria-hidden="true">↻</span>' +
      '</a>';
    // 置于右侧列表首位（视觉上最靠右上角）
    bar.insertBefore(li, bar.firstChild);

    var root = li.querySelector(".kq-top");
    li.addEventListener("click", function (ev) {
      ev.preventDefault();
      load(li);
    });
    load(li);
  }

  function ready(fn) {
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", fn);
    } else {
      fn();
    }
  }

  ready(function () {
    try {
      // 首页（kokuu-home 接管的落地页）不显示一言
      if (document.body.classList.contains("kokuu-on")) { return; }
      // 其余页面（后台 / 皮肤库 / 鉴权）在顶栏右侧显示
      mountTopbar();
    } catch (e) {
      if (window.console) { console.error("[KokuuQuote]", e); }
    }
  });

  // 公共 API
  window.KokuuQuote = { random: fetchQuote };
})();
