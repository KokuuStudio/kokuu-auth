<?php

use App\Services\Hook;

/*
 * KokuuSkin 后台界面重塑（kokuu-ui）
 *
 * 本插件是 kokuu-home 主题插件的**补充**，在 package.json 中通过
 * `"require": { "kokuu-home": "^1.0.0" }` 声明依赖，复用其品牌与虚空主题。
 * 注意：Blessing Skin 在扫描插件时若发现依赖未启用，会**自动禁用本插件**，
 *       因此安装顺序必须为 kokuu-home → 本插件。
 *
 * 定位：对 Blessing Skin 后台（用户中心 / 皮肤库 / 管理后台）做
 * "大刀阔斧"的界面重塑，而**不重写 React 业务逻辑**：
 *   - rebuild.js：用 JS 在 DOM 层面重建 AdminLTE 外壳
 *     （侧边栏 → 悬浮分离式布局、内容区重排、顶栏玻璃化、背景层注入）
 *   - apple.css：Apple 扁平设计系统（大留白 / 纯净面 / 细腻阴影 / 大圆角）
 *   - motion.css：页面过渡、卡片入场 stagger、悬停浮起等流畅动画
 *   - teyvat.css：提瓦特元素点缀（七元素 / 地区意象），克制不喧宾夺主
 *
 * React 继续渲染内容区并处理数据与交互，本插件只替换"舞台"。
 * 配色变量（--a-*）由 apple.css 自身定义，因此即使 kokuu-home 的
 * theme.css 缺失，样式依然完整可用。
 */

return function ($plugin) {
    // Apple 扁平视觉系统（基础层）。依赖 kokuu-home 先加载（其 theme.css/void.css
    // 提供底层配色与虚空深色），本插件在其之上做层次 / 圆角 / 间距的 Apple 化重塑。
    Hook::addStyleFileToPage($plugin->assets('apple.css'), ['*']);

    // 动画系统
    Hook::addStyleFileToPage($plugin->assets('motion.css'), ['*']);

    // 提瓦特元素装饰（七元素 / 地区意象，克制点缀）
    Hook::addStyleFileToPage($plugin->assets('teyvat.css'), ['*']);

    // 首页由 kokuu-home 接管，本插件不介入（保持首页设计）
    // 后台：注入外壳重建脚本
    Hook::addScriptFileToPage(
        $plugin->assets('rebuild.js'),
        ['user', 'user/*', 'admin', 'admin/*', 'skinlib', 'skinlib/*']
    );
};
