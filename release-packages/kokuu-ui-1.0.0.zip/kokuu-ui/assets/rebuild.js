/* =========================================================
   KokuuSkin 后台外壳重建（kokuu-ui）
   注入到 user/admin/skinlib 页面 `</body>` 之前（DOM 已就绪）。

   与 kokuu-home 的关系：
     - kokuu-home 提供品牌、配色、虚空深色主题
     - 本脚本为 apple.css / motion.css 提供"启用类"与 DOM 编排，
       并对 AdminLTE 外壳做无侵入的增强（折叠、进场 stagger），
       React 继续渲染内容区并处理数据交互。

   设计原则：不破坏 AdminLTE / React 的既有行为，只做加法。
   ========================================================= */
(function () {
  "use strict";

  var BODY_CLASS = "kokuu-apple";
  var IN_CLASS = "kokuu-in";

  function ready(fn) {
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", fn);
    } else {
      fn();
    }
  }

  /* 标记 body，启用 apple.css 的作用域样式 */
  function markBody() {
    document.body.classList.add(BODY_CLASS);
  }

  /* 侧边栏折叠：接管 pushmenu 按钮，状态写 localStorage，跨页保持 */
  function initSidebar() {
    var toggle = document.querySelector('[data-widget="pushmenu"]');
    var sidebar = document.querySelector(".main-sidebar");
    if (!toggle || !sidebar) { return; }

    var KEY = "kokuu_sidebar_collapsed";
    var stored = null;
    try { stored = localStorage.getItem(KEY); } catch (e) { /* 忽略 */ }

    function isCollapsed() {
      return document.body.classList.contains("sidebar-collapse");
    }
    function apply(collapsed) {
      document.body.classList.toggle("sidebar-collapse", collapsed);
      try {
        localStorage.setItem(KEY, collapsed ? "1" : "0");
      } catch (e) { /* 忽略 */ }
    }

    if (stored === "1") { apply(true); }
    else if (stored === "0") { apply(false); }

    // AdminLTE 的 pushmenu 自带 toggle；但要接管持久化，
    // 监听其点击（事件委托，避免被 AdminLTE 停止冒泡）
    toggle.addEventListener("click", function () {
      // 等待 AdminLTE 完成自身切换后同步状态
      setTimeout(function () { apply(isCollapsed()); }, 60);
    });
  }

  /* 内容区卡片 stagger 进场：给顶层卡片加递增延迟的 .kokuu-in */
  function staggerCards() {
    var host =
      document.querySelector(".content-wrapper") || document.body;
    var cards = host.querySelectorAll(
      ".content > .container-fluid > .card, .content > .container-fluid > .row, .d-flex.flex-wrap > .card, .d-flex.flex-wrap > a > .card"
    );
    var i = 0;
    for (var k = 0; k < cards.length; k++) {
      var el = cards[k];
      if (el.classList.contains(IN_CLASS)) { continue; }
      el.classList.add(IN_CLASS);
      // 容器级（前几个 block 卡片）给较大间隔，网格内卡片快速递增
      el.style.setProperty("--kokuu-in-delay", (i * 0.055).toFixed(3) + "s");
      i++;
      if (i > 40) { i = 40; } // 防止过多累积延迟
    }
  }

  /* React 异步渲染完成后，把新出现的卡片也补上进场动画 */
  function watchForNewCards() {
    if (!("MutationObserver" in window)) {
      setTimeout(staggerCards, 400);
      return;
    }
    var host = document.querySelector(".content-wrapper") || document.body;
    var mo = new MutationObserver(function () {
      staggerCards();
    });
    mo.observe(host, { childList: true, subtree: true });
    // 观察一段时间后停止，节省开销
    setTimeout(function () { mo.disconnect(); }, 8000);
  }

  /* 自适应：大屏恢复正常边距，小屏默认折叠侧栏（Apple 移动端观感） */
  function responsive() {
    var mq = window.matchMedia("(max-width: 992px)");
    function apply() {
      if (mq.matches) {
        document.body.classList.add("sidebar-collapse");
      }
    }
    apply();
    if (mq.addEventListener) { mq.addEventListener("change", apply); }
    else if (mq.addListener) { mq.addListener(apply); }
  }

  function mount() {
    try {
      markBody();
      initSidebar();
      staggerCards();
      responsive();
      watchForNewCards();
    } catch (e) {
      if (window.console) { console.error("[KokuuUI]", e); }
    }
  }

  ready(mount);
})();
